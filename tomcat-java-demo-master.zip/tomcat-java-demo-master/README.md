> ### SQL文件: db/tables_ly_tomcat.sql
> ### 数据库配置：src/main/resources/application.yml
> ### 对应课程：https://ke.qq.com/course/344137
![avatar](https://github.com/lizhenliang/Shell-Python-Document/blob/master/%E8%81%94%E7%B3%BB%E6%96%B9%E5%BC%8F.jpg)
